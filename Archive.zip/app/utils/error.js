export const customError = (error) => {
  console.log("----------------- ERROR MESSAGE ------------------------");
  console.log("----------------- ERROR MESSAGE ------------------------");
  console.log(error.message);
  console.log("----------------- ERROR MESSAGE ------------------------");
  console.log("----------------- ERROR MESSAGE ------------------------");
};
