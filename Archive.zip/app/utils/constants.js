export const ROUTES = {
  APP: {
    INDEX: "/",
    BULK_OPERATION: "/app/bulk_operation",
  },
  API: {
    BULK_OPERATION: {
      COUNT: "/app/api/bulk_operation_count",
      UPDATE_PRODUCT: "/app/api/update_products",
    },
  },
};

export const STATIC_FILES = {
  PRODUCT_VARIANTS: "./public/static/productVariants.jsonl",
};
