import { unstable_createFileUploadHandler } from "@remix-run/node";

export const standardFileUploadHandler = unstable_createFileUploadHandler({
  directory: "public/productVariants",
  avoidFileConflicts: true,
  maxPartSize: 50000000, // 50M
});
