import { Queue } from "quirrel/remix";
// import superjson from "superjson";
// import { emitter } from "~/common/emitter";

export const updateProductQueueEvtName = "addJobQueue";

export const updateProductQueue = Queue(
  "api/queue/update_product",
  async ({ textContent }) => {
    // const updateQuantitiesResponse = await admin.graphql(
    //   `mutation inventorySetOnHandQuantities($input: InventorySetOnHandQuantitiesInput!) {
    //     inventorySetOnHandQuantities(input: $input) {
    //       userErrors {
    //         field
    //         message
    //       }
    //     }
    //   }`,
    //   {
    //     variables: {
    //       input: {
    //         reason: "correction",
    //         setQuantities: [...quantitiesMutations],
    //       },
    //     },
    //   }
    // );
    // const updateQuantitiesData = await updateQuantitiesResponse.json();
    // if (
    //   updateQuantitiesData?.data?.inventorySetOnHandQuantities?.userErrors
    //     ?.length > 0
    // ) {
    //   throw new Error("Can not update variants quantities");
    // }
  }
);
