import { json, redirect } from "@remix-run/node";
import {
  Page,
  Layout,
  BlockStack,
  Button,
  Card,
  Text,
  ButtonGroup,
  Banner,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { useFetcher, useLoaderData } from "@remix-run/react";
import { useEffect } from "react";
import { ROUTES } from "../utils/constants";
import { debounce } from "lodash";
import db from "../db.server";
import { customError } from "../utils/error";
import { useIsFirstRender } from "../hooks/useFirstRender";

export const loader = async ({ request }) => {
  try {
    const configData = await db.configApp.findFirst({});

    if (configData?.id) {
      return json(configData);
    }

    return redirect("/");
  } catch (error) {
    return redirect("/");
  }
};

export const action = async ({ request }) => {
  try {
    const { admin } = await authenticate.admin(request);

    const response = await admin.graphql(
      `#graphql
      mutation {
        bulkOperationRunQuery(
        query: """
        {
          products {
            edges {
              node {
                id
                variants {
                  edges {
                    node {
                      id
                      sku
                      inventoryItem {
                        id
                      }
                    }
                  }
                }
              }
            }
          }
        }
          """
        ) {
          bulkOperation {
            id
            status
            objectCount
            fileSize
            url
            type
          }
          userErrors {
            field
            message
          }
        }
      }`
    );

    const responseJson = await response.json();

    return json({
      bulkOperation: {
        ...responseJson?.data?.bulkOperationRunQuery?.bulkOperation,
      },
    });
  } catch (error) {
    customError(error);

    return json({
      bulkOperation: null,
      message: "Can not export products data",
    });
  }
};

export default function BulkOperation() {
  return (
    <Page>
      <ui-title-bar title="Epicor - Sync Products"></ui-title-bar>
      <BlockStack gap="500">
        <Layout>
          <Layout.Section>
            <BulkOperationData />
          </Layout.Section>
          <Layout.Section variant="oneThird"></Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}

function BulkOperationData() {
  const loaderData = useLoaderData();
  const { submit, data, state } = useFetcher();
  const isFirstRender = useIsFirstRender();
  const actionType = data?.bulkOperation?.type;
  const status = data?.bulkOperation?.status;
  const isError = data?.message;
  const downloadUrl = data?.bulkOperation?.url;
  const isChecking = Boolean(
    status && status != "COMPLETED" && actionType && actionType != "MUTATION"
  );
  const isSubmit = Boolean(downloadUrl && actionType == "QUERY");

  const submitBulkProcess = () => {
    submit(null, {
      action: ROUTES.API.BULK_OPERATION.COUNT,
      method: "POST",
      encType: "application/json",
      relative: "route",
    });
  };

  const createBulkOperation = () => {
    submit(null, { method: "POST" });
  };

  useEffect(() => {
    if (isChecking) {
      debounce(() => {
        console.log("--- CHECK ---");
        submitBulkProcess();
      }, 4000)();
    }
  }, [isChecking, isFirstRender]);

  useEffect(() => {
    if (isSubmit) {
      console.log("--- SUBMIT ---");

      submit(
        { productsFileUrl: downloadUrl, ...loaderData },
        {
          action: ROUTES.API.BULK_OPERATION.UPDATE_PRODUCT,
          method: "POST",
          encType: "application/json",
          relative: "route",
        }
      );
    }
  }, [isSubmit, loaderData]);

  return (
    <Card padding={{ sm: "400", lg: "800" }}>
      <BlockStack inlineAlign="start" gap="400">
        <Text as="h2" variant="headingSm">
          SYNC PRODUCT DATA (PRICE, INVENTORY QUANTITY)
        </Text>

        {actionType == "MUTATION" &&
          (status == "COMPLETED" || status == "CREATED") && (
            <Banner title="Sync products data successfully." tone="success" />
          )}
        {isError && <Banner title={data.message} tone="critical" />}

        <Text variant="bodyMd" as="span"></Text>

        <ButtonGroup>
          <Button onClick={createBulkOperation} loading={state != "idle"}>
            Sync price, quantities
          </Button>
        </ButtonGroup>
      </BlockStack>
    </Card>
  );
}
