import { json } from "@remix-run/node";
import axios from "axios";
import JSONL from "jsonl-parse-stringify";
import { authenticate } from "../shopify.server";
import { parallel, waterfall } from "async";
import { customError } from "../utils/error";
import fs from "fs";

const log_file = fs.createWriteStream(__dirname + "/debug.log", {
  flags: "w",
});

export const action = async ({ request }) => {
  try {
    const {
      productsFileUrl,
      companyCode,
      listCode,
      UOMCode,
      apiCode,
      username,
      password,
    } = await request.json();

    if (
      !productsFileUrl ||
      !companyCode ||
      !listCode ||
      !UOMCode ||
      !apiCode ||
      !username ||
      !password
    ) {
      throw new Error("Missing arguments");
    }

    const { admin } = await authenticate.admin(request);

    console.log(productsFileUrl);

    /********************** Get location id ***********************
     *************************************************************/
    const locationResponse = await admin.graphql(
      `#graphql
      {
        locations(first: 5) {
          edges {
            node {
              id
            }
          }
        }
      }`
    );

    const locationsData = await locationResponse.json();

    if (!locationsData?.data?.locations?.edges?.[0]?.node?.id) {
      throw new Error("Can not get location ID");
    }

    const locations = locationsData.data.locations.edges;
    const defaultLocationID = locations[0].node.id;

    /********** Download file from query bulk mutation ***********
     *************************************************************/
    const { data } = await axios.get(productsFileUrl);

    const productVariants = JSONL.parse(data);

    let quantitiesMutations = [];
    let mutationProductVariants = await Promise.all(
      productVariants.map(async (variant) => {
        if (!variant?.sku) return;

        const results = await getEpicorVariantData({
          variantSKU: variant.sku,
          companyCode,
          listCode,
          UOMCode,
          apiCode,
          username,
          password,
        });

        if (results?.price && results?.quantity) {
          quantitiesMutations.push({
            inventoryItemId: variant.inventoryItem.id,
            locationId: defaultLocationID,
            quantity: Number(results?.quantity),
          });

          return {
            input: {
              id: variant.id,
              price: results?.price,
              inventoryItem: {
                tracked: true,
              },
            },
          };
        }
      })
    );

    mutationProductVariants = mutationProductVariants.filter(
      (variant) => variant
    );

    /****************** Create staged files to shopify *****************
     *******************************************************************/
    const stagedTargetsResponse = await admin.graphql(
      `#graphql
      mutation stagedUploadsCreate($input: [StagedUploadInput!]!) {
        stagedUploadsCreate(input: $input) {
          stagedTargets {
            url
            resourceUrl
            parameters {
              name
              value
            }
          }
        }
      }`,
      {
        variables: {
          input: [
            {
              filename: "productVariants.jsonl",
              mimeType: "text/jsonl",
              httpMethod: "POST",
              resource: "BULK_MUTATION_VARIABLES",
            },
          ],
        },
      }
    );

    const stagedTargetsData = await stagedTargetsResponse.json();

    const stagedTarget =
      stagedTargetsData?.data?.stagedUploadsCreate?.stagedTargets?.[0];

    const { url, resourceUrl, parameters } = stagedTarget;

    /****************** Upload staged files to shopify *****************
     *******************************************************************/
    if (!stagedTarget || !url || !resourceUrl || !parameters) {
      throw new Error("Can not upload image");
    }

    const uploadFileFormData = new FormData();

    parameters.forEach(({ name, value }) => {
      uploadFileFormData.append(name, value);
    });

    const file = new File(
      [JSONL.stringify(mutationProductVariants)],
      "product_variant.jsonl",
      {
        type: "text/jsonl",
      }
    );

    uploadFileFormData.append("file", file);

    const uploadFile = await axios.post(url, uploadFileFormData);

    if (uploadFile.status != 201) {
      throw new Error("Can not upload image");
    }

    /******************** Update variant quantities **********************
     *******************************************************************/
    if (quantitiesMutations.length > 0) {
      const chunkQuantityMutations = chunkIntoN(quantitiesMutations, 50);

      await waterfall([
        ...chunkQuantityMutations.map((quantitiesMutation) => {
          return async () => {
            const updateQuantitiesResponse = await admin.graphql(
              `mutation inventorySetOnHandQuantities($input: InventorySetOnHandQuantitiesInput!) {
                inventorySetOnHandQuantities(input: $input) {
                  userErrors {
                    field
                    message
                  }
                }
              }`,
              {
                variables: {
                  input: {
                    reason: "correction",
                    setQuantities: [...quantitiesMutation],
                  },
                },
              }
            );

            const updateQuantitiesData = await updateQuantitiesResponse.json();

            if (
              updateQuantitiesData?.data?.inventorySetOnHandQuantities
                ?.userErrors?.length > 0
            ) {
              throw new Error("Can not update variants quantities");
            }
          };
        }),
      ]);
    }

    /********** Create a productVariants update bulk mutation ***********
     *******************************************************************/
    const stagedUploadPath = parameters.find(
      (parameter) => parameter.name == "key"
    )?.value;

    if (!stagedUploadPath) {
      throw new Error("Can not found staged upload path");
    }

    const bulkMutationResponse = await admin.graphql(
      `mutation {
        bulkOperationRunMutation(
          mutation: "mutation call ($input: ProductVariantInput!) { productVariantUpdate(input: $input) { productVariant { id } userErrors { message field } } }",
          stagedUploadPath: "${stagedUploadPath}") {
          bulkOperation {
            id
            status
            objectCount
            fileSize
            url
            type
          }
          userErrors {
            message
            field
          }
        }
      }`
    );

    const bulkMutation = await bulkMutationResponse.json();

    return json({
      bulkOperation: {
        ...bulkMutation?.data?.bulkOperationRunMutation?.bulkOperation,
      },
    });
  } catch (error) {
    customError(error);

    return json({
      bulkOperation: null,
      message: "Can not import products data",
    });
  }
};

/************************* UTILITY FUNCTIONS ****************************/
async function epicorAxiosGet({ url, apiCode, authorizationCode }) {
  const { data } = await axios.get(url, {
    headers: {
      "X-API-Key": apiCode,
      Authorization: `Basic ${authorizationCode}`,
    },
  });

  return data;
}

async function getEpicorVariantData({
  variantSKU,
  companyCode,
  listCode,
  UOMCode,
  apiCode,
  username,
  password,
}) {
  try {
    const authorizationCode = Buffer.from(`${username}:${password}`).toString(
      "base64"
    );

    let results = await parallel({
      price: async () => {
        const priceList = await epicorAxiosGet({
          url: `https://epicor.canecreek.com/EpicorERP/api/v1/Erp.BO.PriceLstSvc/PriceLsts(${companyCode},${listCode})/PriceLstParts(${companyCode},${listCode},${variantSKU},${UOMCode})`,
          apiCode,
          authorizationCode,
        });

        return priceList?.BasePrice;
      },
      quantity: async () => {
        const quantity = await epicorAxiosGet({
          url: `https://epicor.canecreek.com/EpicorERP/api/v1/Erp.BO.PartSvc/Parts(${companyCode},${variantSKU})/PartWhses`,
          apiCode,
          authorizationCode,
        });

        return quantity?.value?.[0]?.OnHandQty;
      },
    });

    log_file.write(`${variantSKU}  -- Done\n`);

    return results;
  } catch (error) {
    log_file.write(`${variantSKU}  -- Failed\n`);

    return { price: null, quantity: null };
  }
}

const chunkIntoN = (arr, n) => {
  const size = Math.ceil(arr.length / n);

  return Array.from({ length: n }, (v, i) =>
    arr.slice(i * size, i * size + size)
  );
};
