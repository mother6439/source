import { json } from "@remix-run/node";
import {
  useActionData,
  useLoaderData,
  useNavigate,
  useNavigation,
  useRouteError,
  useSubmit,
} from "@remix-run/react";
import { boundary } from "@shopify/shopify-app-remix/server";
import {
  BlockStack,
  Box,
  Button,
  ButtonGroup,
  Card,
  FormLayout,
  InlineStack,
  Layout,
  Page,
  Text,
  TextField,
} from "@shopify/polaris";
import db from "../db.server";
import { useEffect, useState } from "react";
import { RefreshIcon } from "@shopify/polaris-icons";
import { ROUTES } from "../utils/constants";

export const loader = async ({ request }) => {
  try {
    const configData = await db.configApp.findFirst({});

    return json({ configData });
  } catch (error) {
    return json({ configData: null });
  }
};

export const action = async ({ request }) => {
  try {
    const { id, companyCode, listCode, UOMCode, apiCode, username, password } =
      await request.json();

    if (
      !companyCode ||
      !listCode ||
      !UOMCode ||
      !apiCode ||
      !username ||
      !password
    ) {
      return json({ success: false });
    }

    let configData;

    if (id) {
      configData = await db.configApp.update({
        where: {
          id: id,
        },
        data: {
          companyCode,
          listCode,
          UOMCode,
          apiCode,
          username,
          password,
        },
        select: {
          id: true,
        },
      });
    } else {
      configData = await db.configApp.create({
        data: {
          companyCode,
          listCode,
          UOMCode,
          apiCode,
          username,
          password,
        },
        select: {
          id: true,
        },
      });
    }

    return json({ success: Boolean(configData?.id) });
  } catch (error) {
    return json({ success: false });
  }
};

export default function App() {
  const { configData: defaultConfigData } = useLoaderData();
  const submit = useSubmit();
  const { state } = useNavigation();
  const actionData = useActionData();
  const navigate = useNavigate();
  const [configData, setConfigData] = useState({
    companyCode: defaultConfigData?.companyCode || "",
    listCode: defaultConfigData?.listCode || "",
    UOMCode: defaultConfigData?.UOMCode || "",
    apiCode: defaultConfigData?.apiCode || "",
    username: defaultConfigData?.username || "",
    password: defaultConfigData?.password || "",
  });

  const isSaveDisabled =
    configData.companyCode == "" ||
    configData.listCode == "" ||
    configData.UOMCode == "" ||
    configData.apiCode == "" ||
    configData.username == "" ||
    configData.password == "";

  const isUpdateEnable =
    configData.companyCode != defaultConfigData?.companyCode ||
    configData.listCode != defaultConfigData?.listCode ||
    configData.UOMCode != defaultConfigData?.UOMCode ||
    configData.apiCode != defaultConfigData?.apiCode ||
    configData.username != defaultConfigData?.username ||
    configData.password != defaultConfigData?.password;

  useEffect(() => {
    if (actionData) {
      const actionName = defaultConfigData?.id ? "Update" : "Create";
      shopify.toast.show(
        actionData?.success
          ? `${actionName} config data successfully`
          : `${actionName} config data failed`
      );
    }
  }, [actionData]);

  const onCreateNewConfigData = () => {
    submit(configData, { method: "POST", encType: "application/json" });
  };

  const onUpdateConfigData = () => {
    submit(
      { id: defaultConfigData?.id, ...configData },
      { method: "POST", encType: "application/json" }
    );
  };

  const onResetConfigData = () => {
    setConfigData({
      ...defaultConfigData,
    });
  };

  return (
    <Page>
      <Layout>
        <Layout.Section>
          <Card roundedAbove="sm">
            <Text as="h2" variant="headingSm">
              UPDATE CONFIG DATA
            </Text>
            <Box paddingBlock="200">
              <BlockStack gap="200">
                <FormLayout>
                  <FormLayout.Group>
                    <TextField
                      type="text"
                      disabled={state == "submitting"}
                      value={configData.companyCode}
                      label="Company code"
                      placeholder="Company code"
                      onChange={(newCompanyCode) =>
                        setConfigData({
                          ...configData,
                          companyCode: newCompanyCode,
                        })
                      }
                      autoComplete="off"
                    />
                    <TextField
                      type="text"
                      disabled={state == "submitting"}
                      value={configData.listCode}
                      label="List code"
                      placeholder="List code "
                      onChange={(newlistCode) =>
                        setConfigData({
                          ...configData,
                          listCode: newlistCode,
                        })
                      }
                      autoComplete="off"
                    />
                    <TextField
                      type="text"
                      disabled={state == "submitting"}
                      value={configData.UOMCode}
                      label="UOM code"
                      placeholder="UOM code"
                      onChange={(newUOMCode) =>
                        setConfigData({
                          ...configData,
                          UOMCode: newUOMCode,
                        })
                      }
                      autoComplete="off"
                    />
                  </FormLayout.Group>
                  <FormLayout.Group condensed>
                    <TextField
                      type="text"
                      disabled={state == "submitting"}
                      value={configData.apiCode}
                      label="API Code"
                      placeholder="API Code"
                      onChange={(newApiCode) =>
                        setConfigData({
                          ...configData,
                          apiCode: newApiCode,
                        })
                      }
                      autoComplete="off"
                    />
                    <TextField
                      type="text"
                      disabled={state == "submitting"}
                      value={configData.username}
                      label="Username"
                      placeholder="Username"
                      onChange={(newUsername) =>
                        setConfigData({
                          ...configData,
                          username: newUsername,
                        })
                      }
                      autoComplete="off"
                    />
                    <TextField
                      // type="password"
                      type="text"
                      disabled={state == "submitting"}
                      value={configData.password}
                      label="Password"
                      placeholder="Password"
                      onChange={(newPassword) =>
                        setConfigData({
                          ...configData,
                          password: newPassword,
                        })
                      }
                      autoComplete="off"
                    />
                  </FormLayout.Group>
                </FormLayout>
                <Box paddingBlockStart="400">
                  <InlineStack align="end">
                    {defaultConfigData?.companyCode ? (
                      <ButtonGroup gap="400">
                        <Button
                          icon={RefreshIcon}
                          onClick={() => navigate(ROUTES.APP.BULK_OPERATION)}
                        >
                          Sync bulk products
                        </Button>
                        <Button
                          onClick={onResetConfigData}
                          disabled={!isUpdateEnable}
                        >
                          Cancel
                        </Button>
                        <Button
                          variant="primary"
                          disabled={!isUpdateEnable}
                          loading={state == "submitting"}
                          onClick={onUpdateConfigData}
                        >
                          Update
                        </Button>
                      </ButtonGroup>
                    ) : (
                      <ButtonGroup gap="400">
                        <Button
                          variant="primary"
                          loading={state == "submitting"}
                          onClick={onCreateNewConfigData}
                          disabled={isSaveDisabled}
                        >
                          Save
                        </Button>
                      </ButtonGroup>
                    )}
                  </InlineStack>
                </Box>
              </BlockStack>
            </Box>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}

export function ErrorBoundary() {
  return boundary.error(useRouteError());
}

export const headers = (headersArgs) => {
  return boundary.headers(headersArgs);
};
