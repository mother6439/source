import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";
import { customError } from "../utils/error";

export const action = async ({ request }) => {
  try {
    const { admin } = await authenticate.admin(request);

    const response = await admin.graphql(
      `#graphql
        query {
          currentBulkOperation {
            id
            status
            errorCode
            createdAt
            completedAt
            objectCount
            fileSize
            url
            partialDataUrl
            type
          }
        }`
    );

    const responseJson = await response.json();
    const bulkOperation = responseJson?.data?.currentBulkOperation;

    return json({ bulkOperation: { ...bulkOperation } });
  } catch (error) {
    customError(error);

    return json({
      bulkOperation: null,
    });
  }
};
